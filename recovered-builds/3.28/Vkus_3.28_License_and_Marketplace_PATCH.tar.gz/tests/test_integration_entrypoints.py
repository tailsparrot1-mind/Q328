from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class IntegrationEntrypointTests(unittest.TestCase):
    def test_license_store_entry_is_in_sidebar_and_uses_current_url(self):
        source = (ROOT / "vkus" / "app.py").read_text(encoding="utf-8")
        self.assertIn("'Купить лицензию', self._open_license_store", source)
        self.assertIn("https://raw.githack.com/tailsparrot1-mind/Vkus-Development/", source)
        self.assertIn("VKUS/Vkus_Store_PC/index_logo_fullscreen.html", source)

    def test_birzha_opens_shared_marketplace_gate(self):
        source = (ROOT / "vkus" / "app.py").read_text(encoding="utf-8")
        self.assertIn("from .exchange_marketplace import open_cloud_marketplace_window", source)
        self.assertIn("open_cloud_marketplace_window(self.root)", source)

    def test_marketplace_role_artwork_exists(self):
        artwork = ROOT / "vkus" / "assets" / "marketplace_role_gate.png"
        self.assertTrue(artwork.is_file())
        self.assertGreater(artwork.stat().st_size, 10_000)

    def test_role_gate_uses_exact_artwork_hitbox_mapping_and_no_sidebar_draw(self):
        source = (ROOT / "vkus" / "exchange_marketplace.py").read_text(encoding="utf-8")
        self.assertIn('"marketplace_role_gate.png"', source)
        self.assertIn('x0 + 34 * scale', source)
        self.assertIn('x0 + 620 * scale', source)
        self.assertIn('def show_registration_screen(role):', source)
        self.assertIn('client.sign_up(email_var.get(), password_var.get(), role=selected_role["value"])', source)
        self.assertNotIn('gate_canvas.create_rectangle(0, 0, 238, window_height', source)
        self.assertIn('win._marketplace_gate_canvas = gate_canvas', source)
        self.assertIn('win._marketplace_show_role_screen = show_role_screen', source)
        self.assertIn('win._marketplace_selected_role = selected_role', source)


if __name__ == "__main__":
    unittest.main()
